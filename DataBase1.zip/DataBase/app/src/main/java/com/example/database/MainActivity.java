package com.example.database;

import static com.example.database.List_Activity.file;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_CAMERA = 100;
    private static final int PICK_IMAGE_GALLERY = 200;
    EditText etxtName, etxtNum;
    Button add;
    ImageView imageView;
    private String inputStreamImg;
    private Bitmap bitmap;
    private File destination;
    private String imgPath;
    Uri selectedImage;
    private String savedImgPath;
    String imgName;
    Uri ImageURI;
    int id;
    String name, number, image;
    File downloadedFile;
    final CharSequence[] items = {"Camera", "Gallery"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etxtName = findViewById(R.id.eTxtName);
        etxtNum = findViewById(R.id.eTxtNum);
        add = findViewById(R.id.btnAdd);
        imageView = findViewById(R.id.takeImage);
        MyDataBase db = new MyDataBase(MainActivity.this);

        id = getIntent().getIntExtra("id", 0);
        name = getIntent().getStringExtra("name");
        number = getIntent().getStringExtra("number");
        image = getIntent().getStringExtra("imageurl");
        Log.d("UUU", "onCreate: img from adapter="+image);


        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED)
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA}, 500);

        if (getIntent().getExtras() != null)
        {
            etxtName.setText("" + name);
            etxtNum.setText("" + number);
            imageView.setImageURI(Uri.parse(image));
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //db.addData(etxtName.getText().toString(), etxtNum.getText().toString(), String.valueOf(ImageURI));

                if (getIntent().getExtras() == null) {

                    String name1 = etxtName.getText().toString();
                    String number1 = etxtNum.getText().toString();
                    String image1 = ImageURI.toString();
                    db.addData("" + name1, "" + number1, "" + image1);
                }
                else {
                    String name1 = etxtName.getText().toString();
                    String number1 = etxtNum.getText().toString();
                    String image1 = ImageURI.toString();
                    db.updatedata(id, "" + name1, "" + number1, "" + image1);
                }
                Intent intent = new Intent(MainActivity.this, List_Activity.class);
                startActivity(intent);
            }
        });
//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Cursor cursor = db.viewData();
//                while (cursor.moveToNext()) {
//                    Log.d("NNN", "onClick: id=" + cursor.getInt(0));
//                    Log.d("NNN", "onClick: name=" + cursor.getString(1));
//                    Log.d("NNN", "onClick: number=" + cursor.getString(2));
//                }
//                Intent intent = new Intent(MainActivity.this, List_Activity.class);
//                startActivity(intent);
//            }
//        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImgOther();
            }
        });
    }
    private void selectImgOther() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Choose Image");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (items[which].equals("Camera")) {
                    launchCamera();
                } else if (items[which].equals("Gallery")) {
                    Intent GalleryIntent = null;
                    GalleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    GalleryIntent.setType("image/*");
                    GalleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(GalleryIntent, 0);
                }
            }
        });
        builder.show();
        if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // If not granted, request the CAMERA permission
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.CAMERA}, 100);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //from gallery
        if (requestCode == 0 && resultCode == RESULT_OK && data != null) {
            Log.d("LLL", "CODE in Gallery=" + requestCode);
            Bundle extras = data.getExtras();
            Uri selectedImageUri = data.getData();
            Log.d("UUU", "onActivityResult: extras="+selectedImageUri);
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            //Bitmap bitmap = (Bitmap) extras.get("data");;
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,bytes);
            imageView.setImageBitmap(bitmap);
            SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMDD_HHmmss", Locale.getDefault());
            String currentDateandTime=sdf.format(new Date());
            downloadedFile=new File(file.getAbsolutePath()+"/IMG_"+currentDateandTime+".jpg");
            try {
                downloadedFile.createNewFile();
                FileOutputStream fo=new FileOutputStream(downloadedFile);
                fo.write(bytes.toByteArray());
                Toast.makeText(MainActivity.this, "File Downloaded", Toast.LENGTH_SHORT).show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            ImageURI= Uri.parse(downloadedFile.getAbsolutePath());


        }
        // for take image from camera
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            // Get the captured image from the intent's data
            Bundle extras = data.getExtras();
            if (extras != null) {
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                if (imageBitmap != null) {
                    // The image is in the extras as a bitmap
                    imageView.setImageBitmap(imageBitmap);
                    // Save the bitmap to internal storage and get the URI
                    ImageURI = Uri.parse(saveToInternalStorage(imageBitmap));
                    Log.d("MMM", "Main: URI in Main Camera==" + ImageURI);
                    loadImageFromStorage(savedImgPath);
                } else {
                    // Handle the case where the bitmap is null
                    Log.e("LLL", "Camera: Bitmap is null");
                }
            } else {
                // Handle the case where extras is null
                Log.e("LLL", "Camera: Extras is null");
            }
        }
    }
    private void launchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, 100);
        }
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with launching the camera
                launchCamera();
            } else {
                // Permission denied, handle accordingly (e.g., show a message to the user)
            }
        }
    }
    private String saveToInternalStorage(Bitmap bitmapImage) {
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        Random r=new Random();
        r.nextInt(1000000);
        imgName="img_"+r.toString()+".jpg";
        Log.d("LLL", "saveToInternalStorage: Name="+imgName);
        File mypath = new File(directory+"/"+imgName);
        Log.d("MMM", "PATH=" + mypath);
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return String.valueOf(mypath);
    }
    private void loadImageFromStorage(String path) {

        try {
            Log.d("MMM", "LOOAD: path=" + path+imgName);
            File f = new File(path+imgName);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            imageView.setImageBitmap(b);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
