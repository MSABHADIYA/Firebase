package com.example.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyDataBase extends SQLiteOpenHelper
{
    String TAG="MMM";
    public MyDataBase(@Nullable Context context) {
        super(context, "Contact", null, 1);
        Log.d(TAG, "MyDataBase: Database Created..");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="create table ContactBook(ID integer primary key autoincrement,NAME text,NUMBER text,IMG_PATH text)";
        db.execSQL(query);
        Log.d(TAG, "onCreate: Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public void addData(String name, String number, String imgPath) {
        String query="insert into ContactBook(NAME,NUMBER,IMG_PATH) values('"+name+"','"+number+"','"+imgPath+"')";
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL(query);
    }
    public Cursor viewData()
    {
        String query="select * from ContactBook";
        SQLiteDatabase db=getReadableDatabase();
        Cursor cursor=db.rawQuery(query,null);
        return cursor;
    }
    public void deleteData(Integer id) {
        String query="delete from ContactBook where ID="+id+"";
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL(query);
    }

    public void updatedata(int id, String name, String number, String image) {
        String query = "update ContactBook set NAME='"+name+"',NUMBER='"+number+"',IMG_PATH='"+image+"' WHERE ID="+ id;
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL(query);
    }
}
